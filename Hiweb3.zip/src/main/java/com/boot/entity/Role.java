package com.boot.entity;

//열거형 상수
public enum Role {
	ROLE_MEMBER,
	ROLE_ADMIN
}

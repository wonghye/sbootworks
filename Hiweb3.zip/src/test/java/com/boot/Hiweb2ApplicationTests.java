package com.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hiweb2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
